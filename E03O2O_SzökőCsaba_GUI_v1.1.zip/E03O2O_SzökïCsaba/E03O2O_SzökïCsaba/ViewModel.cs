﻿using E03O2O_SzökőCsaba.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace E03O2O_SzökőCsaba
{
    internal class ViewModel
    {

        public BindingList<Recipe> Recipes { get; set; }

        public BindingList<Ingredient> Ingredients { get; set; }

        public Recipe SelectedRecipe { get; set; }

        public Ingredient SelectedIngredient { get; set; }



        public ViewModel()
        {
            Ingredients = new BindingList<Ingredient>();
            Recipes = new BindingList<Recipe>();

            Ingredients.Add(new Ingredient ("Cukor"));
            Ingredients.Add(new Ingredient ("Só"));

            Recipes.Add(new Recipe("Palacsinta","Palacsinta Desc",4));
        }
    }
}
