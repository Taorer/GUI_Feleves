﻿using E03O2O_SzökőCsaba.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace E03O2O_SzökőCsaba
{
    /// <summary>
    /// Interaction logic for RecipeDetailsWindow.xaml
    /// </summary>
    public partial class RecipeDetailsWindow : Window
    {

        public RecipeDetailsWindow()
        {
            InitializeComponent();
        }
        internal RecipeDetailsWindow(Recipe recipe)
        {
            InitializeComponent();

            RecipeNameTextBlock.Text = recipe.Name;
            DescriptionTextBlock.Text = recipe.Description;
            IngredientsListBox.ItemsSource = recipe.Ingredients;
        }
    }
}
