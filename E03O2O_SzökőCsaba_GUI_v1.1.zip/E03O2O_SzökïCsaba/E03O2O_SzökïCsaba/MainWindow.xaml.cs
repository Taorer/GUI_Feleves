﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace E03O2O_SzökőCsaba
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (this.DataContext is ViewModel)
            {
                var viewModel = DataContext as ViewModel;

                if (viewModel != null)
                {
                    var addWindow = new AddIngredientWindow(viewModel);
                    addWindow.ShowDialog();
                }
            }
        }

        private void RemoveIngredient_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as ViewModel;

            if (viewModel != null && viewModel.SelectedIngredient != null)
            {
                viewModel.Ingredients.Remove(viewModel.SelectedIngredient);
            }
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;

                var addRecipeWindow = new AddRecipeWindow(vm);
                addRecipeWindow.ShowDialog();
        }

        private void RemoveRecipe_Click(object sender, RoutedEventArgs e)
        {

        }

        private void ViewRecipe_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;
            if (vm?.SelectedRecipe != null)
            {
                var detailsWindow = new RecipeDetailsWindow(vm.SelectedRecipe);
                detailsWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a recipe to view.", "No Recipe Selected", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }
    }
}