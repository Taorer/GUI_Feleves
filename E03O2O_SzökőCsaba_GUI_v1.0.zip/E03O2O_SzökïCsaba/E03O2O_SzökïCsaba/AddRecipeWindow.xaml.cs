﻿using E03O2O_SzökőCsaba.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace E03O2O_SzökőCsaba
{
    /// <summary>
    /// Interaction logic for AddRecipeWindow.xaml
    /// </summary>
    public partial class AddRecipeWindow : Window
    {
        private ViewModel mainViewModel;
        private List<Ingredient> addedIngredients = new List<Ingredient>();
        public AddRecipeWindow()
        {
            InitializeComponent();
        }

        internal AddRecipeWindow(ViewModel mainviewmodel)
        {
            InitializeComponent();
            this.mainViewModel = mainviewmodel;
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (AllIngredientsComboBox.SelectedItem is Ingredient selectedIngredient)
            {
                //duplikálás check
                if (!addedIngredients.Contains(selectedIngredient))
                {
                    addedIngredients.Add(selectedIngredient);
                    AddedIngredientsListBox.Items.Add(selectedIngredient);
                }
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            string recipeDescription = DescriptionTextBox.Text;

            //új recept legenerálása
            Recipe newRecipe = new Recipe(recipeName, recipeDescription, 1, addedIngredients.ToList());

            mainViewModel.Recipes.Add(newRecipe);

            this.DialogResult = true;
            this.Close();
        }
    }
}
