﻿using E03O2O_SzökőCsaba.Model;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace E03O2O_SzökőCsaba
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void AddIngredient_Click(object sender, RoutedEventArgs e)
        {
            if (this.DataContext is ViewModel)
            {
                var viewModel = DataContext as ViewModel;

                if (viewModel != null)
                {
                    var addWindow = new AddIngredientWindow(viewModel);
                    addWindow.ShowDialog();
                }
            }
        }

        private void RemoveIngredient_Click(object sender, RoutedEventArgs e)
        {
            var viewModel = DataContext as ViewModel;

            if (viewModel != null && viewModel.SelectedIngredient != null)
            {
                viewModel.Ingredients.Remove(viewModel.SelectedIngredient);
            }
        }

        private void AddRecipe_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;

                var addRecipeWindow = new AddRecipeWindow(vm);
                addRecipeWindow.ShowDialog();
        }

        private void RemoveRecipe_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;
            if (vm?.SelectedRecipe != null)
            {
                vm.Recipes.Remove(vm.SelectedRecipe);
                vm.SelectedRecipe = null;
            }
            else
            {
                MessageBox.Show("Please select a recipe to remove.");
            }
        }

        private void ViewRecipe_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;
            if (vm?.SelectedRecipe != null)
            {
                var detailsWindow = new RecipeDetailsWindow(vm.SelectedRecipe);
                detailsWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select a recipe to view.");
            }
        }

        private void SelectIngredient_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;
            if (vm?.SelectedIngredient != null && !vm.IngredientsAtHome.Contains(vm.SelectedIngredient))
            {
                vm.IngredientsAtHome.Add(vm.SelectedIngredient);
            }
            UpdateRecipeBackgrounds();
        }

        private void DeselectIngredient_Click(object sender, RoutedEventArgs e)
        {
            var vm = DataContext as ViewModel;
            if (vm?.SelectedIngredient != null)
            {
                vm.IngredientsAtHome.Remove(vm.SelectedIngredient);
                vm.SelectedIngredient = null;
            }
            UpdateRecipeBackgrounds();
        }

        public void UpdateRecipeBackgrounds()
        {
            var vm = DataContext as ViewModel;
            if (vm == null) return;

            for (int i = 0; i < RecipesListBox.Items.Count; i++)
            {
                var item = RecipesListBox.ItemContainerGenerator.ContainerFromIndex(i) as ListBoxItem;
                if (item == null) continue;

                var recipe = RecipesListBox.Items[i] as Recipe;
                if (recipe == null) continue;

                bool canMake = recipe.Ingredients.All(ing => vm.IngredientsAtHome.Any(atHome => atHome.Name == ing.Name));
                item.Background = canMake ? Brushes.Transparent : Brushes.LightCoral;
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateRecipeBackgrounds();
        }

    }
}