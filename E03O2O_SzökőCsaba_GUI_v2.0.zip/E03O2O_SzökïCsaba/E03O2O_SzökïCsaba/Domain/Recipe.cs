﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace E03O2O_SzökőCsaba.Model
{
    internal class Recipe
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public int Difficulty { get; set; }
        public List<Ingredient> Ingredients { get; set; }

        public bool CanBeMadeAtHome = true;

        public Recipe(string name, string description, int difficulty, List<Ingredient> ingredients)
        {
            this.Name = name;
            this.Description = description;
            this.Difficulty = difficulty;
            this.Ingredients = ingredients;
        }

        public Recipe(string name, string description, int difficulty)
        {
            this.Name = name;
            this.Description = description;
            this.Difficulty = difficulty;
            this.Ingredients = new List<Ingredient>();
        }

        public void AddIngredient(Ingredient ingredient)
        { 
        Ingredients.Add(ingredient);
        }

        public override string ToString()
        {
            return Name;
        }
    }
}
