﻿using E03O2O_SzökőCsaba.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;

namespace E03O2O_SzökőCsaba
{
    internal class ViewModel
    {

        public BindingList<Recipe> Recipes { get; set; }

        public BindingList<Ingredient> Ingredients { get; set; }

        public BindingList<Ingredient> IngredientsAtHome { get; set; }

        public Recipe SelectedRecipe { get; set; }

        public Ingredient SelectedIngredient { get; set; }



        public ViewModel()
        {
            Ingredients = new BindingList<Ingredient>();
            Recipes = new BindingList<Recipe>();
            IngredientsAtHome = new BindingList<Ingredient>();

            IngredientsAtHome.Add(new Ingredient ("Cukor"));
            IngredientsAtHome.Add(new Ingredient ("Só"));
            Ingredients.Add(new Ingredient("Tojás"));
            Ingredients.Add(new Ingredient("Só"));
            Ingredients.Add(new Ingredient("Cukor"));
        }

        //public bool CanMakeRecipe(Recipe recipe)
        //{
        //    return recipe.Ingredients.All(ing => IngredientsAtHome.Any(h => h.Name == ing.Name));
        //}
    }
}
