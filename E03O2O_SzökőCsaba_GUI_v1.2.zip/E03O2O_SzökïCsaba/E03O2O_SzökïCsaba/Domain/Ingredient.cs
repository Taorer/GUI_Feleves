﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace E03O2O_SzökőCsaba.Model
{
    internal class Ingredient : INotifyPropertyChanged
    {

        private string name { get; set; }

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        private int quantity { get; set; }

        public int Quantity
        {
            get { return quantity; }
            set
            {
                if (quantity != value)
                {
                    quantity = value;
                    OnPropertyChanged(nameof(Quantity));
                }
            }
        }

        private QuantityType quantityType { get; set; }

        public QuantityType QuantityType
        {
            get { return quantityType; }
            set
            {
                if (quantityType != value)
                {
                    quantityType = value;
                    OnPropertyChanged(nameof(QuantityType));
                }
            }
        }


        private bool haveAtHome { get; set; }

        public bool HaveAtHome
        {
            get { return haveAtHome; }
            set
            {
                if (haveAtHome != value)
                {
                    haveAtHome = value;
                    OnPropertyChanged(nameof(HaveAtHome));
                }
            }
        }


        public Ingredient(string name, int quantity, QuantityType quantityType)
        {
            this.Name = name;
            this.Quantity = quantity;
            this.quantityType = quantityType;
        }

        public Ingredient(string name)
        {
            this.name = name;
        }

        public event PropertyChangedEventHandler? PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public override string ToString()
        {
            //if (quantityType != null)
            //{
            //    string Quantity_Type = quantityType.ToString();
            //    return $"{Quantity} {Quantity_Type} {name}";
            //}
            return name;
        }
    }

    public enum QuantityType
    {
        Gramm,
        Kilogramm,
        Milliliter,
        Liter,
        Darab,
        Evokanal,
        Teaskanal,
        Csipetnyi,
        Csepp
    }
}
